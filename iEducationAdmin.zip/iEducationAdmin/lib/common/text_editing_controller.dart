import '../libs.dart';

/// Add Student List
TextEditingController txtStudentFnameController = TextEditingController();
TextEditingController txtStudentLnameController = TextEditingController();
TextEditingController txtStudentMNameController = TextEditingController();
TextEditingController txtStudentAddressController = TextEditingController();
TextEditingController txtStudentEmailController = TextEditingController();
TextEditingController txtStudentPhoneNoController = TextEditingController();
TextEditingController txtStudentBirthDateController = TextEditingController();
TextEditingController txtStudentPinCodeController = TextEditingController();
TextEditingController txtStudentEnrollmentControl = TextEditingController();
TextEditingController txtStudentSpidController = TextEditingController();
TextEditingController txtStudentCasteController = TextEditingController();

///Add Time Tablet
TextEditingController txtLectureName = TextEditingController();
TextEditingController txtLectureDate = TextEditingController();
TextEditingController txtLectureStartTime = TextEditingController();
TextEditingController txtLectureEndTime = TextEditingController();
// TextEditingController txtLectureSubject =TextEditingController();
// TextEditingController txtLectureTime = TextEditingController();

///Add  Staff List
TextEditingController txtFnameStaffControl = TextEditingController();
TextEditingController txtDegreeStaffControl = TextEditingController();
TextEditingController txtPostStaffControl = TextEditingController();
TextEditingController txtEmailStaffControl = TextEditingController();
TextEditingController txtPhoneNoStaffControl = TextEditingController();
TextEditingController txtSubjectStaffControl = TextEditingController();
TextEditingController txtExperienceStaffControl = TextEditingController();

/// Notice
TextEditingController txtCultureTitle = TextEditingController();
TextEditingController txtCultureDescription = TextEditingController();

TextEditingController txtCollegeActivityTitle = TextEditingController();
TextEditingController txtCollegeActivityDescription = TextEditingController();

TextEditingController txtSportTitle = TextEditingController();
TextEditingController txtSportDescription = TextEditingController();

TextEditingController txtCongratulationTitle = TextEditingController();
TextEditingController txtCongratulationDescription = TextEditingController();

TextEditingController txtJobVacancyTitle = TextEditingController();
TextEditingController txtJobVacancyDescription = TextEditingController();

TextEditingController txtGeneralTitle = TextEditingController();
TextEditingController txtGeneralDescription = TextEditingController();

TextEditingController txtCompetitiveExamTitle = TextEditingController();
TextEditingController txtCompetitiveExamDescription = TextEditingController();

/// Add Materials
TextEditingController txtMaterialSubject = TextEditingController();
TextEditingController txtMaterialDate = TextEditingController();
TextEditingController txtMaterialTime = TextEditingController();

/// Add Course
TextEditingController txtCourseSubject = TextEditingController();
TextEditingController txtCourseDate = TextEditingController();
TextEditingController txtCourseTime = TextEditingController();

/// Add Results
TextEditingController txtResultDate = TextEditingController();
TextEditingController txtResultTime = TextEditingController();

// **** Assignment ****
TextEditingController txtAssignmentSubject = TextEditingController();
TextEditingController txtAssignmentDate = TextEditingController();
TextEditingController txtAssignmentTime = TextEditingController();

// **** Fees ****
TextEditingController txtFeesStudentController = TextEditingController();
TextEditingController txtTotalFeesController = TextEditingController();
TextEditingController txtPaidFeesController = TextEditingController();
TextEditingController txtRemainingFeesController = TextEditingController();
