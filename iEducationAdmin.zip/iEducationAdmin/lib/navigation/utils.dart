enum RouteType {
  defaultRoute,
  fade,
  left,
  up,
  down,
  top,
  right,
}
